<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
$conn = mysqli_connect("localhost","root","","a_shop");
$id = $_GET ['id'];

$sql = "SELECT * FROM users WHERE id = {$id}'";
$run = mysql_query ($conn,$sql);
$row = mysql_fetch_assoc ($run)
?>

 <form action="update.php" method = "post">

    <input type="hidden" name= "id" value="<?php echo $row ['id'];?>"><b></b>
    <input type="text" name= "username" id="" value="<?php echo $row ['Username'];?>"><b></b>
    <input type="text" name= "email"id="" value="<?php echo $row ['email'];?>"><b></b>
    <input type="text" name= "address" id="" value="<?php echo $row ['Address'];?>"><b></b>
    <input type="text" name= "phone" id ="" value="<?php echo $row ['PhoneNo'];?>"><b></b>
    <input type="submit" value="Update" name="updatebtn">
 </form>








</body>
</html>